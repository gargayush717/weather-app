import React from 'react'
import { useState } from 'react'
  import { useDispatch } from 'react-redux'
import {setval } from '../redux/slice'

function Search() {
const [search,setsearch]=useState('')

const dispatch = useDispatch()
const handlechange = (e) =>{
    e.preventDefault();
    setsearch(e.target.value)
}
const Submit=(e)=>{
  e.preventDefault();
dispatch(setval(search))
}



  return (
    <>
    <form onSubmit={Submit}>
        <input type="text" onChange={handlechange}/>
        <button type="submit"> Search</button>
    </form>
    
    
 
    
    </>
  )
  }


export default Search
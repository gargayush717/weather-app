import React from 'react'
import axios from 'axios';
import { useEffect,useState,useContext } from 'react';
import { useSelector } from 'react-redux'



function Weather() {
  
   const city = useSelector((state) => state.city.value)

const[weather,setweather]=useState([]);
useEffect(()=>{
const apikey = '347c2815f13b472da0453035252005';
const result = axios.get(`http://api.weatherapi.com/v1/current.json?key=${apikey}&q=${city}`)
result.then((res)=>{
 setweather(res.data.current)
    },[city])
   


})
  return (
    <>
    <h2>{weather.temp_c}</h2>
    
    </>
  )
}

export default Weather

import Search from "./Components/Search"
import Weather from "./Components/Weather"

function App() {

  return (
    <>
<Search/>
 <Weather/>
    </>
  )
}

export default App

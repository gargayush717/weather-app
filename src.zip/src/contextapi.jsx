 import React from "react";
 let ContextData=React.createContext()
 let Provider=ContextData.Provider 
 let Consumer=ContextData.Consumer

 export{Provider,Consumer,ContextData}